#!/bin/bash
mkdir $HOME/.minecraft
cp -rfvu minecraft/*  $HOME/.minecraft/
