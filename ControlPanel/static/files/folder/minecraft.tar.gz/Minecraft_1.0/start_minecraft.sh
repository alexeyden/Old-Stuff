#!/bin/bash

GAMEPATH=$HOME/.minecraft
nickname=

if [ ! $nickname ]; then
  echo "Enter your nickname (default is: ${defname})"
  read nickname
fi

if [ ! $nickname ]; then
  nickname=$defname
fi
java -Xmx768M -Xms512M -cp "$GAMEPATH/bin/*" \
  -Djava.library.path="$GAMEPATH/bin/natives/" net.minecraft.client.Minecraft "$nickname"
